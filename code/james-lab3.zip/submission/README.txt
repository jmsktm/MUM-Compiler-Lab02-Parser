Submission by:
James Singh
983976

- The parser works for all test files provided.
- 6 files were created with error. Comments have been included in the files with error mentioning what is in error.
- Parser errors out when running those files. Error files have been included.
- Works for associativity and precedence
- Dangling else problem solved.
